﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo3D
{
    public  class Scene
    {
        public List<Figura> Cubes;
        public Scene()
        {
            Cubes = new List<Figura>();
        }
    }
}
