using System.Numerics;

namespace Figuras3DV2
{
    public partial class Form1 : Form
    {
        Graphics g;
        Bitmap bmp;
        Cono cone;
        Rotation rot = new Rotation();
        Projection proj = new Projection();
        float angle = 0;
        Cilindro cilindro;
        Esfera esfera;
        Elipsoide elipsoide;
        List<float[]> normalList = new List<float[]>();
        bool conoBoton, cilindroBoton, esferaBoton, elipsoideBoton;
        bool xBoton, yBoton, zBoton, xyzBoton;

        public Form1()
        {
            InitializeComponent();

            bmp = new Bitmap(PCT_CANVAS.Width, PCT_CANVAS.Height);
            PCT_CANVAS.Image = bmp;
            g = Graphics.FromImage(bmp);
            Init();
            timer1.Start();
        }

        public void Init()
        {
            var baseCenter = new Vertex(new float[] { 0, 0, 0 });
            var radius = 1f;
            var height = 2f;
            cone = new Cono(baseCenter, radius, height);
            cilindro = new Cilindro(baseCenter, radius, height);
            var divisions = 9;
            var division = 18;
            esfera = new Esfera(baseCenter, radius,division);
            var radiusX = 2f;
            var radiusY = 1.5f;
            var radiusZ = 1f;
            elipsoide = new Elipsoide(baseCenter, radiusX, radiusY, radiusZ, divisions);
            PCT_CANVAS.Invalidate();
                
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            g.Clear(Color.Black);
            Pen pen = new Pen(Color.White, 3);
            Pen pen1 = new Pen(Color.White, 1);
            g.DrawLine(pen1, 0, PCT_CANVAS.Height / 2, PCT_CANVAS.Width, PCT_CANVAS.Height / 2);
            g.DrawLine(pen1, PCT_CANVAS.Width / 2, 0, PCT_CANVAS.Width / 2, PCT_CANVAS.Height);

            if (conoBoton)
            {
                if (xBoton)
                {
                    
                    foreach (var face in cone.Faces)
                    {
                        var points = new List<PointF>();
                        foreach (var vertex in face.Triangulos)
                        {
                            // Escalar y trasladar cada v�rtice para obtener su posici�n en la pantalla
                            var rotacionVertex = TransformPointX(angle, vertex);
                            var projectedVertex = proj.Perspective(rotacionVertex);
                            var scaledVertex = ScaleVertex(projectedVertex, 130);
                            var translatedVertex = TraslateCenter(scaledVertex, PCT_CANVAS.Width / 2, PCT_CANVAS.Height / 2);

                            // Agregar el punto a la lista de puntos
                            points.Add(new PointF(translatedVertex.x, translatedVertex.y));
                        }
                        g.DrawPolygon(Pens.Orange, points.ToArray());
                    }
                }
                else if (yBoton)
                {
                    foreach (var face in cone.Faces)
                    {
                        var points = new List<PointF>();
                        foreach (var vertex in face.Triangulos)
                        {
                            // Escalar y trasladar cada v�rtice para obtener su posici�n en la pantalla
                            var rotacionVertex = TransformPointY(angle, vertex);
                            var projectedVertex = proj.Perspective(rotacionVertex);
                            var scaledVertex = ScaleVertex(projectedVertex, 130);
                            var translatedVertex = TraslateCenter(scaledVertex, PCT_CANVAS.Width / 2, PCT_CANVAS.Height / 2);

                            // Agregar el punto a la lista de puntos
                            points.Add(new PointF(translatedVertex.x, translatedVertex.y));
                        }
                        g.DrawPolygon(Pens.Orange, points.ToArray());
                    }
                }
                else if (zBoton)
                {
                    foreach (var face in cone.Faces)
                    {
                        var points = new List<PointF>();
                        foreach (var vertex in face.Triangulos)
                        {
                            // Escalar y trasladar cada v�rtice para obtener su posici�n en la pantalla
                            var rotacionVertex = TransformPointZ(angle, vertex);
                            var projectedVertex = proj.Perspective(rotacionVertex);
                            var scaledVertex = ScaleVertex(projectedVertex, 130);
                            var translatedVertex = TraslateCenter(scaledVertex, PCT_CANVAS.Width / 2, PCT_CANVAS.Height / 2);

                            // Agregar el punto a la lista de puntos
                            points.Add(new PointF(translatedVertex.x, translatedVertex.y));
                        }
                        g.DrawPolygon(Pens.Orange, points.ToArray());
                    }
                }
                else if (xyzBoton)
                {
                    foreach (var face in cone.Faces)
                    {
                        var points = new List<PointF>();
                        foreach (var vertex in face.Triangulos)
                        {
                            // Escalar y trasladar cada v�rtice para obtener su posici�n en la pantalla
                            var rotacionVertex = TransformPoint(angle, vertex);
                            var projectedVertex = proj.Perspective(rotacionVertex);
                            var scaledVertex = ScaleVertex(projectedVertex, 130);
                            var translatedVertex = TraslateCenter(scaledVertex, PCT_CANVAS.Width / 2, PCT_CANVAS.Height / 2);

                            // Agregar el punto a la lista de puntos
                            points.Add(new PointF(translatedVertex.x, translatedVertex.y));
                        }
                        g.DrawPolygon(Pens.Orange, points.ToArray());
                    }
                }
                else if (!xBoton && !yBoton && !zBoton && !xyzBoton)
                {
                    foreach (var face in cone.Faces)
                    {
                        var points = new List<PointF>();
                        foreach (var vertex in face.Triangulos)
                        {
                            // Escalar y trasladar cada v�rtice para obtener su posici�n en la pantalla
                            var rotacionVertex = TransformPoint(angle, vertex);
                            var projectedVertex = proj.Perspective(rotacionVertex);
                            var scaledVertex = ScaleVertex(projectedVertex, 130);
                            var translatedVertex = TraslateCenter(scaledVertex, PCT_CANVAS.Width / 2, PCT_CANVAS.Height / 2);

                            // Agregar el punto a la lista de puntos
                            points.Add(new PointF(translatedVertex.x, translatedVertex.y));
                        }
                        g.DrawPolygon(Pens.Orange, points.ToArray());
                    }
                }

            }
            else if (cilindroBoton)
            {
                if(xBoton)
                {
                    foreach (var face in cilindro.Faces)
                    {
                        var points = new List<PointF>();
                        foreach (var vertex in face.Vertices)
                        {

                            // Escalar y trasladar cada v�rtice para obtener su posici�n en la pantalla
                            var rotacionVertex = TransformPointX(angle, vertex);
                            var projectedVertex = proj.Ortograph(rotacionVertex);
                            var scaledVertex = ScaleVertex(projectedVertex, 60);
                            var translatedVertex = TraslateCenter(scaledVertex, PCT_CANVAS.Width / 2, PCT_CANVAS.Height / 2);

                            // Agregar el punto a la lista de puntos
                            points.Add(new PointF(translatedVertex.x, translatedVertex.y));
                        }

                        // Dibujar la cara con un color s�lido
                        var faceBrush = new SolidBrush(face.Color);
                        //g.FillPolygon(faceBrush, points.ToArray()); 
                        g.DrawPolygon(Pens.Orange, points.ToArray());
                    }
                }
                else if (yBoton)
                {
                    foreach (var face in cilindro.Faces)
                    {
                        var points = new List<PointF>();
                        foreach (var vertex in face.Vertices)
                        {

                            // Escalar y trasladar cada v�rtice para obtener su posici�n en la pantalla
                            var rotacionVertex = TransformPointY(angle, vertex);
                            var projectedVertex = proj.Ortograph(rotacionVertex);
                            var scaledVertex = ScaleVertex(projectedVertex, 60);
                            var translatedVertex = TraslateCenter(scaledVertex, PCT_CANVAS.Width / 2, PCT_CANVAS.Height / 2);

                            // Agregar el punto a la lista de puntos
                            points.Add(new PointF(translatedVertex.x, translatedVertex.y));
                        }

                        // Dibujar la cara con un color s�lido
                        var faceBrush = new SolidBrush(face.Color);
                        //g.FillPolygon(faceBrush, points.ToArray()); 
                        g.DrawPolygon(Pens.Orange, points.ToArray());
                    }
                }
                else if (zBoton)
                {
                    foreach (var face in cilindro.Faces)
                    {
                        var points = new List<PointF>();
                        foreach (var vertex in face.Vertices)
                        {

                            // Escalar y trasladar cada v�rtice para obtener su posici�n en la pantalla
                            var rotacionVertex = TransformPointZ(angle, vertex);
                            var projectedVertex = proj.Ortograph(rotacionVertex);
                            var scaledVertex = ScaleVertex(projectedVertex, 60);
                            var translatedVertex = TraslateCenter(scaledVertex, PCT_CANVAS.Width / 2, PCT_CANVAS.Height / 2);

                            // Agregar el punto a la lista de puntos
                            points.Add(new PointF(translatedVertex.x, translatedVertex.y));
                        }

                        // Dibujar la cara con un color s�lido
                        var faceBrush = new SolidBrush(face.Color);
                        //g.FillPolygon(faceBrush, points.ToArray()); 
                        g.DrawPolygon(Pens.Orange, points.ToArray());
                    }
                }
                else if (xyzBoton)
                {
                    foreach (var face in cilindro.Faces)
                    {
                        var points = new List<PointF>();
                        foreach (var vertex in face.Vertices)
                        {

                            // Escalar y trasladar cada v�rtice para obtener su posici�n en la pantalla
                            var rotacionVertex = TransformPoint(angle, vertex);
                            var projectedVertex = proj.Ortograph(rotacionVertex);
                            var scaledVertex = ScaleVertex(projectedVertex, 60);
                            var translatedVertex = TraslateCenter(scaledVertex, PCT_CANVAS.Width / 2, PCT_CANVAS.Height / 2);

                            // Agregar el punto a la lista de puntos
                            points.Add(new PointF(translatedVertex.x, translatedVertex.y));
                        }

                        // Dibujar la cara con un color s�lido
                        var faceBrush = new SolidBrush(face.Color);
                        //g.FillPolygon(faceBrush, points.ToArray()); 
                        g.DrawPolygon(Pens.Orange, points.ToArray());
                    }
                }
                else if (!xBoton && !yBoton && !zBoton && !xyzBoton)
                {
                    foreach (var face in cilindro.Faces)
                    {
                        var points = new List<PointF>();
                        foreach (var vertex in face.Vertices)
                        {

                            // Escalar y trasladar cada v�rtice para obtener su posici�n en la pantalla
                            var rotacionVertex = TransformPoint(angle, vertex);
                            var projectedVertex = proj.Ortograph(rotacionVertex);
                            var scaledVertex = ScaleVertex(projectedVertex, 60);
                            var translatedVertex = TraslateCenter(scaledVertex, PCT_CANVAS.Width / 2, PCT_CANVAS.Height / 2);

                            // Agregar el punto a la lista de puntos
                            points.Add(new PointF(translatedVertex.x, translatedVertex.y));
                        }

                        // Dibujar la cara con un color s�lido
                        var faceBrush = new SolidBrush(face.Color);
                        //g.FillPolygon(faceBrush, points.ToArray()); 
                        g.DrawPolygon(Pens.Orange, points.ToArray());
                    }
                }
            }
            else if (esferaBoton)
            {
                if(xBoton) 
                {
                    foreach (var face in esfera.Faces)
                    {
                        var points = new List<PointF>();

                        foreach (var vertex in face.Triangulos)
                        {
                            // Escalar y trasladar cada v�rtice para obtener su posici�n en la pantalla
                            var rotacionVertex = TransformPointX(angle, vertex);
                            var projectedVertex = proj.Perspective(rotacionVertex);
                            var scaledVertex = ScaleVertex(projectedVertex, 360);
                            var translatedVertex = TraslateCenter(scaledVertex, PCT_CANVAS.Width / 2, PCT_CANVAS.Height / 2);

                            // Agregar el punto a la lista de puntos
                            points.Add(new PointF(translatedVertex.x, translatedVertex.y));
                        }

                        // Dibujar la cara con un color s�lido
                        var faceBrush = new SolidBrush(face.Color);
                        g.DrawPolygon(Pens.Orange, points.ToArray());
                    }
                }
                else if (yBoton)
                {
                    foreach (var face in esfera.Faces)
                    {
                        var points = new List<PointF>();

                        foreach (var vertex in face.Triangulos)
                        {
                            // Escalar y trasladar cada v�rtice para obtener su posici�n en la pantalla
                            var rotacionVertex = TransformPointY(angle, vertex);
                            var projectedVertex = proj.Perspective(rotacionVertex);
                            var scaledVertex = ScaleVertex(projectedVertex, 360);
                            var translatedVertex = TraslateCenter(scaledVertex, PCT_CANVAS.Width / 2, PCT_CANVAS.Height / 2);

                            // Agregar el punto a la lista de puntos
                            points.Add(new PointF(translatedVertex.x, translatedVertex.y));
                        }

                        // Dibujar la cara con un color s�lido
                        var faceBrush = new SolidBrush(face.Color);
                        g.DrawPolygon(Pens.Orange, points.ToArray());
                    }
                }
                else if(zBoton) 
                {
                    foreach (var face in esfera.Faces)
                    {
                        var points = new List<PointF>();

                        foreach (var vertex in face.Triangulos)
                        {
                            // Escalar y trasladar cada v�rtice para obtener su posici�n en la pantalla
                            var rotacionVertex = TransformPointZ(angle, vertex);
                            var projectedVertex = proj.Perspective(rotacionVertex);
                            var scaledVertex = ScaleVertex(projectedVertex, 360);
                            var translatedVertex = TraslateCenter(scaledVertex, PCT_CANVAS.Width / 2, PCT_CANVAS.Height / 2);

                            // Agregar el punto a la lista de puntos
                            points.Add(new PointF(translatedVertex.x, translatedVertex.y));
                        }

                        // Dibujar la cara con un color s�lido
                        var faceBrush = new SolidBrush(face.Color);
                        g.DrawPolygon(Pens.Orange, points.ToArray());
                    }
                }  
                else if(xyzBoton) 
                {
                    foreach (var face in esfera.Faces)
                    {
                        var points = new List<PointF>();

                        foreach (var vertex in face.Triangulos)
                        {
                            // Escalar y trasladar cada v�rtice para obtener su posici�n en la pantalla
                            var rotacionVertex = TransformPoint(angle, vertex);
                            var projectedVertex = proj.Perspective(rotacionVertex);
                            var scaledVertex = ScaleVertex(projectedVertex, 360);
                            var translatedVertex = TraslateCenter(scaledVertex, PCT_CANVAS.Width / 2, PCT_CANVAS.Height / 2);

                            // Agregar el punto a la lista de puntos
                            points.Add(new PointF(translatedVertex.x, translatedVertex.y));
                        }

                        // Dibujar la cara con un color s�lido
                        var faceBrush = new SolidBrush(face.Color);
                        g.DrawPolygon(Pens.Orange, points.ToArray());
                    }
                }
                else if (!xBoton && !yBoton && !zBoton && !xyzBoton)
                {
                    foreach (var face in esfera.Faces)
                    {
                        var points = new List<PointF>();

                        foreach (var vertex in face.Triangulos)
                        {
                            // Escalar y trasladar cada v�rtice para obtener su posici�n en la pantalla
                            var rotacionVertex = TransformPoint(angle, vertex);
                            var projectedVertex = proj.Perspective(rotacionVertex);
                            var scaledVertex = ScaleVertex(projectedVertex, 360);
                            var translatedVertex = TraslateCenter(scaledVertex, PCT_CANVAS.Width / 2, PCT_CANVAS.Height / 2);

                            // Agregar el punto a la lista de puntos
                            points.Add(new PointF(translatedVertex.x, translatedVertex.y));
                        }

                        // Dibujar la cara con un color s�lido
                        var faceBrush = new SolidBrush(face.Color);
                        g.DrawPolygon(Pens.Orange, points.ToArray());
                    }
                }
            }
            else if (elipsoideBoton)
            {
                if(xBoton) 
                {
                    foreach (var face in elipsoide.Faces)
                    {
                        var points = new List<PointF>();

                        foreach (var vertex in face.Triangulos)
                        {
                            // Escalar y trasladar cada v�rtice para obtener su posici�n en la pantalla
                            var rotacionVertex = TransformPointX(angle, vertex);
                            var projectedVertex = proj.Ortograph(rotacionVertex);
                            var scaledVertex = ScaleVertex(projectedVertex, 100);
                            var translatedVertex = TraslateCenter(scaledVertex, PCT_CANVAS.Width / 2, PCT_CANVAS.Height / 2);

                            // Agregar el punto a la lista de puntos
                            points.Add(new PointF(translatedVertex.x, translatedVertex.y));
                        }

                        // Dibujar la cara con un color s�lido
                        var faceBrush = new SolidBrush(face.Color);
                        g.DrawPolygon(Pens.Orange, points.ToArray());
                    }
                }
                else if(yBoton)
                {
                    foreach (var face in elipsoide.Faces)
                    {
                        var points = new List<PointF>();

                        foreach (var vertex in face.Triangulos)
                        {
                            // Escalar y trasladar cada v�rtice para obtener su posici�n en la pantalla
                            var rotacionVertex = TransformPointY(angle, vertex);
                            var projectedVertex = proj.Ortograph(rotacionVertex);
                            var scaledVertex = ScaleVertex(projectedVertex, 100);
                            var translatedVertex = TraslateCenter(scaledVertex, PCT_CANVAS.Width / 2, PCT_CANVAS.Height / 2);

                            // Agregar el punto a la lista de puntos
                            points.Add(new PointF(translatedVertex.x, translatedVertex.y));
                        }

                        // Dibujar la cara con un color s�lido
                        var faceBrush = new SolidBrush(face.Color);
                        g.DrawPolygon(Pens.Orange, points.ToArray());
                    }
                }
                else if(zBoton)
                {
                    foreach (var face in elipsoide.Faces)
                    {
                        var points = new List<PointF>();

                        foreach (var vertex in face.Triangulos)
                        {
                            // Escalar y trasladar cada v�rtice para obtener su posici�n en la pantalla
                            var rotacionVertex = TransformPointZ(angle, vertex);
                            var projectedVertex = proj.Ortograph(rotacionVertex);
                            var scaledVertex = ScaleVertex(projectedVertex, 100);
                            var translatedVertex = TraslateCenter(scaledVertex, PCT_CANVAS.Width / 2, PCT_CANVAS.Height / 2);

                            // Agregar el punto a la lista de puntos
                            points.Add(new PointF(translatedVertex.x, translatedVertex.y));
                        }

                        // Dibujar la cara con un color s�lido
                        var faceBrush = new SolidBrush(face.Color);
                        g.DrawPolygon(Pens.Orange, points.ToArray());
                    }
                }
                else if(xyzBoton)
                {
                    foreach (var face in elipsoide.Faces)
                    {
                        var points = new List<PointF>();

                        foreach (var vertex in face.Triangulos)
                        {
                            // Escalar y trasladar cada v�rtice para obtener su posici�n en la pantalla
                            var rotacionVertex = TransformPoint(angle, vertex);
                            var projectedVertex = proj.Ortograph(rotacionVertex);
                            var scaledVertex = ScaleVertex(projectedVertex, 100);
                            var translatedVertex = TraslateCenter(scaledVertex, PCT_CANVAS.Width / 2, PCT_CANVAS.Height / 2);

                            // Agregar el punto a la lista de puntos
                            points.Add(new PointF(translatedVertex.x, translatedVertex.y));
                        }

                        // Dibujar la cara con un color s�lido
                        var faceBrush = new SolidBrush(face.Color);
                        g.DrawPolygon(Pens.Orange, points.ToArray());
                    }
                }
                else if(!xBoton && !yBoton && !zBoton && !xyzBoton)
                {
                    foreach (var face in elipsoide.Faces)
                    {
                        var points = new List<PointF>();

                        foreach (var vertex in face.Triangulos)
                        {
                            // Escalar y trasladar cada v�rtice para obtener su posici�n en la pantalla
                            var rotacionVertex = TransformPointY(angle, vertex);
                            var projectedVertex = proj.Ortograph(rotacionVertex);
                            var scaledVertex = ScaleVertex(projectedVertex, 100);
                            var translatedVertex = TraslateCenter(scaledVertex, PCT_CANVAS.Width / 2, PCT_CANVAS.Height / 2);

                            // Agregar el punto a la lista de puntos
                            points.Add(new PointF(translatedVertex.x, translatedVertex.y));
                        }

                        // Dibujar la cara con un color s�lido
                        var faceBrush = new SolidBrush(face.Color);
                        g.DrawPolygon(Pens.Orange, points.ToArray());
                    }
                }
            }

            PCT_CANVAS.Invalidate();
            angle += .03f;

        }

        private Vertex TransformPointX(float angle, Vertex a)
        {
            a = rot.Rotx(angle, a);
            return a;
        }

        private Vertex TransformPointY(float angle, Vertex a)
        {
            a = rot.Roty(angle, a);
            return a;
        }

        private Vertex TransformPointZ(float angle, Vertex a)
        {
            a = rot.Rotz(angle, a);
            return a;
        }

        private Vertex TransformPoint(float angle, Vertex a)
        {
            a = rot.Rotx(angle, a);
            a = rot.Roty(angle, a);
            a = rot.Rotz(angle, a);
            return a;
        }

        private void rotacionX_Click(object sender, EventArgs e)
        {
            if (!timer1.Enabled)
                timer1.Start();
            xBoton = true;
            yBoton = false;
            zBoton = false;
            xyzBoton = false;
        }

        private void rotacionY_Click(object sender, EventArgs e)
        {
            if (!timer1.Enabled)
                timer1.Start();
            xBoton = false;
            yBoton = true;
            zBoton = false;
            xyzBoton = false;
        }

        private void rotacionZ_Click(object sender, EventArgs e)
        {
            if (!timer1.Enabled)
                timer1.Start();
            xBoton = false;
            yBoton = false;
            zBoton = true;
            xyzBoton = false;
        }

        private void rotacionxyz_Click(object sender, EventArgs e)
        {
            if (!timer1.Enabled)
                timer1.Start();
            xBoton = false;
            yBoton = false;
            zBoton = false;
            xyzBoton = true;
        }

        private Vertex TraslateCenter(Vertex a, int x, int y)
        {
            return new Vertex(new float[]
            {
                a.x + x, a.y + y,a.z
            });
        }


        private Vertex ScaleVertex(Vertex a, float f)
        {
            return new Vertex(new float[]
            {
                a.x *f, a.y *f, a.z *f
            });
        }

        private void elipsoideBtn_Click(object sender, EventArgs e)
        {
            if (!timer1.Enabled)
                timer1.Start();
            conoBoton = false;
            cilindroBoton = false;
            esferaBoton = false;
            elipsoideBoton = true;
        }

        private void conoBtn_Click(object sender, EventArgs e)
        {
            if (!timer1.Enabled)
                timer1.Start();
            conoBoton = true;
            cilindroBoton = false;
        }

        private void esferaBtn_Click(object sender, EventArgs e)
        {
            if (!timer1.Enabled)
                timer1.Start();
            conoBoton = false;
            cilindroBoton = false;
            esferaBoton = true;
        }

        private void cilindroBtn_Click(object sender, EventArgs e)
        {
            if (!timer1.Enabled)
                timer1.Start();
            conoBoton = false;
            cilindroBoton = true;

        }
    }
}
