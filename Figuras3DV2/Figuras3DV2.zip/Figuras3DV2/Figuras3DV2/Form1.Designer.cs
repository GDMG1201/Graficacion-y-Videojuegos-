﻿namespace Figuras3DV2
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.PCT_CANVAS = new System.Windows.Forms.PictureBox();
            this.conoBtn = new System.Windows.Forms.Button();
            this.cilindroBtn = new System.Windows.Forms.Button();
            this.esferaBtn = new System.Windows.Forms.Button();
            this.elipsoideBtn = new System.Windows.Forms.Button();
            this.rotacionX = new System.Windows.Forms.Button();
            this.rotacionY = new System.Windows.Forms.Button();
            this.rotacionZ = new System.Windows.Forms.Button();
            this.rotacionxyz = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.PCT_CANVAS)).BeginInit();
            this.SuspendLayout();
            // 
            // timer1
            // 
            this.timer1.Interval = 30;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // PCT_CANVAS
            // 
            this.PCT_CANVAS.Location = new System.Drawing.Point(12, 12);
            this.PCT_CANVAS.Name = "PCT_CANVAS";
            this.PCT_CANVAS.Size = new System.Drawing.Size(776, 426);
            this.PCT_CANVAS.TabIndex = 0;
            this.PCT_CANVAS.TabStop = false;
            // 
            // conoBtn
            // 
            this.conoBtn.Location = new System.Drawing.Point(814, 44);
            this.conoBtn.Name = "conoBtn";
            this.conoBtn.Size = new System.Drawing.Size(112, 34);
            this.conoBtn.TabIndex = 1;
            this.conoBtn.Text = "Cono";
            this.conoBtn.UseVisualStyleBackColor = true;
            this.conoBtn.Click += new System.EventHandler(this.conoBtn_Click);
            // 
            // cilindroBtn
            // 
            this.cilindroBtn.Location = new System.Drawing.Point(814, 150);
            this.cilindroBtn.Name = "cilindroBtn";
            this.cilindroBtn.Size = new System.Drawing.Size(112, 34);
            this.cilindroBtn.TabIndex = 2;
            this.cilindroBtn.Text = "Cilindro";
            this.cilindroBtn.UseVisualStyleBackColor = true;
            this.cilindroBtn.Click += new System.EventHandler(this.cilindroBtn_Click);
            // 
            // esferaBtn
            // 
            this.esferaBtn.Location = new System.Drawing.Point(814, 269);
            this.esferaBtn.Name = "esferaBtn";
            this.esferaBtn.Size = new System.Drawing.Size(112, 34);
            this.esferaBtn.TabIndex = 3;
            this.esferaBtn.Text = "Esfera";
            this.esferaBtn.UseVisualStyleBackColor = true;
            this.esferaBtn.Click += new System.EventHandler(this.esferaBtn_Click);
            // 
            // elipsoideBtn
            // 
            this.elipsoideBtn.Location = new System.Drawing.Point(814, 373);
            this.elipsoideBtn.Name = "elipsoideBtn";
            this.elipsoideBtn.Size = new System.Drawing.Size(112, 34);
            this.elipsoideBtn.TabIndex = 4;
            this.elipsoideBtn.Text = "Elipsoide";
            this.elipsoideBtn.UseVisualStyleBackColor = true;
            this.elipsoideBtn.Click += new System.EventHandler(this.elipsoideBtn_Click);
            // 
            // rotacionX
            // 
            this.rotacionX.Location = new System.Drawing.Point(44, 476);
            this.rotacionX.Name = "rotacionX";
            this.rotacionX.Size = new System.Drawing.Size(112, 34);
            this.rotacionX.TabIndex = 5;
            this.rotacionX.Text = "Rotar en X";
            this.rotacionX.UseVisualStyleBackColor = true;
            this.rotacionX.Click += new System.EventHandler(this.rotacionX_Click);
            // 
            // rotacionY
            // 
            this.rotacionY.Location = new System.Drawing.Point(246, 476);
            this.rotacionY.Name = "rotacionY";
            this.rotacionY.Size = new System.Drawing.Size(112, 34);
            this.rotacionY.TabIndex = 6;
            this.rotacionY.Text = "Rotar en Y";
            this.rotacionY.UseVisualStyleBackColor = true;
            this.rotacionY.Click += new System.EventHandler(this.rotacionY_Click);
            // 
            // rotacionZ
            // 
            this.rotacionZ.Location = new System.Drawing.Point(437, 476);
            this.rotacionZ.Name = "rotacionZ";
            this.rotacionZ.Size = new System.Drawing.Size(112, 34);
            this.rotacionZ.TabIndex = 7;
            this.rotacionZ.Text = "Rotar en Z";
            this.rotacionZ.UseVisualStyleBackColor = true;
            this.rotacionZ.Click += new System.EventHandler(this.rotacionZ_Click);
            // 
            // rotacionxyz
            // 
            this.rotacionxyz.Location = new System.Drawing.Point(638, 476);
            this.rotacionxyz.Name = "rotacionxyz";
            this.rotacionxyz.Size = new System.Drawing.Size(139, 34);
            this.rotacionxyz.TabIndex = 8;
            this.rotacionxyz.Text = "Rotar en XYZ";
            this.rotacionxyz.UseVisualStyleBackColor = true;
            this.rotacionxyz.Click += new System.EventHandler(this.rotacionxyz_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(951, 564);
            this.Controls.Add(this.rotacionxyz);
            this.Controls.Add(this.rotacionZ);
            this.Controls.Add(this.rotacionY);
            this.Controls.Add(this.rotacionX);
            this.Controls.Add(this.elipsoideBtn);
            this.Controls.Add(this.esferaBtn);
            this.Controls.Add(this.cilindroBtn);
            this.Controls.Add(this.conoBtn);
            this.Controls.Add(this.PCT_CANVAS);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.PCT_CANVAS)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Timer timer1;
        private PictureBox PCT_CANVAS;
        private Button conoBtn;
        private Button cilindroBtn;
        private Button esferaBtn;
        private Button elipsoideBtn;
        private Button rotacionX;
        private Button rotacionY;
        private Button rotacionZ;
        private Button rotacionxyz;
    }
}