﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pruebacolisionq
{
    public class pelota
    {
        public int x;
        public int y;
        public Point speed;
        public Color color;
        public int velx;
        public int vely;

        public pelota()
        {
            Random rdan = new Random();
            this.x = rdan.Next(3, 150);
            this.y = rdan.Next(3, 200);
            this.color = Color.Blue;
            this.velx = rdan.Next(3, 20);
            this.vely = rdan.Next(3, 20);

        }

        public void Update()
        {
            
            x += velx;
            y += vely;
        }

        public void Update2()
        {

            x -= velx;
            y -= vely;
        }
    }

    
}
