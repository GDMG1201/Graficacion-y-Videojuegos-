namespace pruebacolisionq
{
    public partial class Form1 : Form
    {
        private Bitmap bmp;
        static Graphics g;
        private pelota pelota1;

        public Form1()
        {
            InitializeComponent();
                       
            timer2.Start();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            pelota1 = new pelota();
            bmp = new Bitmap(pictureBox1.Width, pictureBox1.Height);
            pictureBox1.Image = bmp;
            g = Graphics.FromImage(bmp);
        }

        public void DrawBall()
        {
            g.Clear(Color.White);
            Brush brush = new SolidBrush(pelota1.color);
            int x = pelota1.x;
            int y = pelota1.y;
            int diameter = 20;
            g.FillEllipse(brush, x, y, diameter, diameter);

            if(x >= 0 && x > bmp.Width)
            {
                pelota1.Update();
            }
            else if(y >= 0 && y > bmp.Height)
            {
                pelota1.Update();
            }
            else
            {
                pelota1.Update2();
            }
            
        }

       
        private void timer2_Tick(object sender, EventArgs e)
        {
            DrawBall();
            pictureBox1.Invalidate();
        }
    }
}